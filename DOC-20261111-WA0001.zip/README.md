# Jarvis

Hands-free Android assistant: "Hey Jarvis" wake word (offline), Siri-style floating popup over any app,
calls (phone or WhatsApp), messages, email, smart home, phone automation, anime code words.

## Get the APK (no PC tools needed)
1. Create a free account at github.com, then a new repository (private is fine).
2. Upload everything in this folder to the repository (keep the `.github` folder).
3. Open the **Actions** tab and wait for "Build Jarvis APK" to go green (about 5 minutes).
4. Open **Releases** on the repo page and download `jarvis.apk` on your phone. Allow "install unknown apps" when asked.
5. Optional website: Settings > Pages > Source = "GitHub Actions". Then re-run the workflow. The plain download page appears at `https://<you>.github.io/<repo>/`.

## First run
Open Jarvis and tick off the SETUP list top to bottom, then tap **Activate Jarvis**. Paste a free Gemini key
(aistudio.google.com) in Settings for the online brain with Google search.

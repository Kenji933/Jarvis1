package com.jarvis.assistant

/** Tiny bridge between the always-on listener service and the popup session. */
object Bus {
    private var listener: ((String) -> Unit)? = null
    private var timeout: (() -> Unit)? = null
    private var pending: String? = null

    @Synchronized
    fun attach(onText: (String) -> Unit, onTimeout: () -> Unit) {
        listener = onText
        timeout = onTimeout
        pending?.let { pending = null; onText(it) }
    }

    @Synchronized fun detach() { listener = null; timeout = null; pending = null }

    @Synchronized
    fun deliver(text: String) {
        val l = listener
        if (l != null) l(text) else pending = text
    }

    @Synchronized fun timedOut() { timeout?.invoke() }
}

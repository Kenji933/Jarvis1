package com.jarvis.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Small helpers so every screen has the same cyan-on-black HUD look. */
object UiKit {
    val CYAN = Color.parseColor("#00E5FF")
    val GOLD = Color.parseColor("#FFB300")
    val BG = Color.parseColor("#05070D")
    val PANEL = Color.parseColor("#0B1220")
    val TEXT = Color.parseColor("#E6F7FF")
    val DIM = Color.parseColor("#8FA9B8")

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun box(ctx: Context, fill: Int = PANEL, stroke: Int = Color.parseColor("#4400E5FF"), radius: Int = 14) =
        GradientDrawable().apply {
            cornerRadius = dp(ctx, radius).toFloat()
            setColor(fill)
            setStroke(dp(ctx, 1), stroke)
        }

    fun title(ctx: Context, s: String) = TextView(ctx).apply {
        text = s; textSize = 12f; letterSpacing = 0.25f; setTextColor(CYAN); typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(ctx, 18), 0, dp(ctx, 6))
    }

    fun text(ctx: Context, s: String, size: Float = 14f, color: Int = TEXT) = TextView(ctx).apply {
        text = s; textSize = size; setTextColor(color)
    }

    fun button(ctx: Context, s: String, filled: Boolean = false, onClick: () -> Unit) = Button(ctx).apply {
        text = s; isAllCaps = true; textSize = 13f
        setTextColor(if (filled) BG else CYAN)
        background = box(ctx, if (filled) CYAN else Color.TRANSPARENT, CYAN, 24)
        setPadding(dp(ctx, 18), dp(ctx, 10), dp(ctx, 18), dp(ctx, 10))
        setOnClickListener { onClick() }
    }

    fun field(ctx: Context, parent: LinearLayout, label: String, value: String, secret: Boolean = false, multiline: Boolean = false): EditText {
        parent.addView(text(ctx, label, 12f, DIM).apply { setPadding(0, dp(ctx, 10), 0, dp(ctx, 3)) })
        val e = EditText(ctx).apply {
            setText(value); setTextColor(TEXT); textSize = 14f
            background = box(ctx, PANEL, Color.parseColor("#3300E5FF"), 10)
            setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
            inputType = when {
                secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (multiline) { minLines = 6; gravity = Gravity.TOP }
        }
        parent.addView(e, LinearLayout.LayoutParams(-1, -2))
        return e
    }

    fun space(ctx: Context, h: Int) = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(1, dp(ctx, h)) }
}

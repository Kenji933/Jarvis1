package com.jarvis.assistant

import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

object Contacts {
    data class Hit(val name: String, val number: String, val contactId: Long)

    private fun has(ctx: Context) =
        ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** Fuzzy match of a spoken name against saved contacts. */
    fun find(ctx: Context, spoken: String): Hit? {
        if (!has(ctx)) return null
        val q = spoken.lowercase().trim()
        if (q.isEmpty()) return null
        var best: Hit? = null
        var bestScore = Int.MAX_VALUE
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID
            ), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val n = name.lowercase()
                val score = when {
                    n == q -> 0
                    n.startsWith(q) || n.split(' ').any { it == q } -> 1
                    n.contains(q) -> 2
                    else -> {
                        val dist = minOf(lev(n, q), n.split(' ').minOf { lev(it, q) })
                        if (dist <= 2 && q.length > 3) 3 + dist else continue
                    }
                }
                if (score < bestScore) {
                    bestScore = score
                    best = Hit(name, c.getString(1) ?: "", c.getLong(2))
                }
            }
        }
        return best
    }

    /** Data row id for a direct WhatsApp voice call to a saved contact (null if the contact isn't on WhatsApp). */
    fun whatsappCallDataId(ctx: Context, contactId: Long, video: Boolean = false): Long? {
        ctx.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID),
            "${ContactsContract.Data.CONTACT_ID}=? AND ${ContactsContract.Data.MIMETYPE}=?",
            arrayOf(contactId.toString(), if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call" else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"), null
        )?.use { if (it.moveToFirst()) return it.getLong(0) }
        return null
    }

    fun email(ctx: Context, spoken: String): String? {
        if (!has(ctx)) return null
        val q = spoken.lowercase().trim()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.CommonDataKinds.Email.ADDRESS),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = (c.getString(0) ?: "").lowercase()
                if (n == q || n.startsWith(q) || n.contains(q)) return c.getString(1)
            }
        }
        return null
    }

    private val words = mapOf(
        "zero" to "0", "oh" to "0", "one" to "1", "two" to "2", "three" to "3", "four" to "4", "five" to "5",
        "six" to "6", "seven" to "7", "eight" to "8", "nine" to "9"
    )

    /** Turns "nine eight double seven 1 2 3 4 5" or "+91 98765 43210" into digits. Null if it isn't a number. */
    fun spokenNumber(s: String): String? {
        val out = StringBuilder()
        val tokens = s.lowercase().replace("-", " ").split(' ').filter { it.isNotBlank() }
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            when {
                t == "plus" -> out.append('+')
                t == "double" && i + 1 < tokens.size -> { val d = words[tokens[i + 1]] ?: tokens[i + 1]; out.append(d).append(d); i++ }
                t == "triple" && i + 1 < tokens.size -> { val d = words[tokens[i + 1]] ?: tokens[i + 1]; out.append(d).append(d).append(d); i++ }
                words.containsKey(t) -> out.append(words[t])
                t.all { it.isDigit() || it == '+' } -> out.append(t)
                else -> return null
            }
            i++
        }
        val digits = out.count { it.isDigit() }
        return if (digits >= 6) out.toString() else null
    }
}

package com.jarvis.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Lets Jarvis read your WhatsApp / Gmail / Instagram notifications aloud and reply to WhatsApp by voice. */
class JarvisNotificationListener : NotificationListenerService() {

    data class Note(val pkg: String, val sender: String, val text: String, val time: Long, val reply: Notification.Action?)

    companion object {
        private val notes = ArrayList<Note>()
        @Volatile var connected = false

        const val WA = "com.whatsapp"
        const val GMAIL = "com.google.android.gm"
        const val IG = "com.instagram.android"

        fun label(pkg: String) = when (pkg) { WA, "com.whatsapp.w4b" -> "WhatsApp"; GMAIL -> "Gmail"; IG -> "Instagram"; else -> pkg }

        @Synchronized
        fun recent(vararg pkgs: String): List<Note> =
            notes.filter { it.pkg in pkgs }.sortedByDescending { it.time }

        @Synchronized
        fun clear(vararg pkgs: String) { notes.removeAll { it.pkg in pkgs } }

        /** Replies to the newest WhatsApp notification (optionally from a given sender). */
        @Synchronized
        fun replyWhatsApp(ctx: Context, who: String?, text: String): String? {
            val n = notes.filter { it.pkg == WA && it.reply != null && (who == null || it.sender.lowercase().contains(who.lowercase())) }
                .maxByOrNull { it.time } ?: return null
            val action = n.reply ?: return null
            val ri = action.remoteInputs?.firstOrNull() ?: return null
            val i = Intent()
            val b = Bundle().apply { putCharSequence(ri.resultKey, text) }
            RemoteInput.addResultsToIntent(action.remoteInputs, i, b)
            action.actionIntent.send(ctx, 0, i)
            return n.sender
        }
    }

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg !in setOf(WA, "com.whatsapp.w4b", GMAIL, IG)) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val e = n.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        synchronized(Companion) {
            notes.add(Note(pkg, title, text, sbn.postTime, reply))
            while (notes.size > 40) notes.removeAt(0)
        }
    }
}

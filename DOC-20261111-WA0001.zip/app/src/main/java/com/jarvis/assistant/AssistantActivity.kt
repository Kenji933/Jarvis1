package com.jarvis.assistant

import android.app.KeyguardManager
import android.app.NotificationManager
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity

/** Same popup, used on the lock screen (shows over it and wakes the screen). */
class AssistantActivity : AppCompatActivity() {
    private lateinit var session: AssistantSession
    private lateinit var panel: AssistantPanel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        getSystemService(NotificationManager::class.java).cancel(3)

        panel = AssistantPanel(this)
        val root = FrameLayout(this)
        val m = (16 * resources.displayMetrics.density).toInt()
        root.addView(EdgeGlowView(this), FrameLayout.LayoutParams(-1, -1))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(m, m, m, m * 3) })
        setContentView(root)

        session = AssistantSession(this, panel)
        panel.onClose = { if (!isFinishing) finish(); session.close() }
        panel.onUnlock = { cont ->
            val km = getSystemService(KeyguardManager::class.java)
            if (km.isKeyguardLocked) {
                km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() { cont() }
                })
            } else cont()
        }
        session.start()
    }

    override fun onDestroy() {
        session.close()
        super.onDestroy()
    }
}

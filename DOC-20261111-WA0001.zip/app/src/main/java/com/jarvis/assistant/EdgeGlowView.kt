package com.jarvis.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View

/** Siri-style glow that pulses around the screen edges while Jarvis is active. Never takes touches. */
class EdgeGlowView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var level = 0.5f
    private val anim = ValueAnimator.ofFloat(0.25f, 1f).apply {
        duration = 1100
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener { level = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val d = minOf(w, h) * 0.07f
        val a = (200 * level).toInt()
        val on = Color.argb(a, 0, 229, 255)
        val off = Color.argb(0, 0, 229, 255)
        fun edge(x0: Float, y0: Float, x1: Float, y1: Float, l: Float, t: Float, r: Float, b: Float) {
            paint.shader = LinearGradient(x0, y0, x1, y1, on, off, Shader.TileMode.CLAMP)
            c.drawRect(l, t, r, b, paint)
        }
        edge(0f, 0f, d, 0f, 0f, 0f, d, h)
        edge(w, 0f, w - d, 0f, w - d, 0f, w, h)
        edge(0f, 0f, 0f, d, 0f, 0f, w, d)
        edge(0f, h, 0f, h - d, 0f, h - d, w, h)
    }
}

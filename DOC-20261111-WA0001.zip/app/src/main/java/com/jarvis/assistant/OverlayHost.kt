package com.jarvis.assistant

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager

/** Floats the assistant over whatever app is open (needs "display over other apps"). */
class OverlayHost(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val panel = AssistantPanel(ctx)
    private val glow = EdgeGlowView(ctx)
    private val session = AssistantSession(ctx, panel)
    private var shown = false

    fun show() {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val glowLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val margin = (16 * ctx.resources.displayMetrics.density).toInt()
        val panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            x = 0; y = margin * 3
            horizontalMargin = 0.03f
        }
        try {
            wm.addView(glow, glowLp)
            wm.addView(panel, panelLp)
            shown = true
        } catch (e: Exception) {
            Assistant.active = false
            return
        }
        panel.onClose = { remove(); session.close() }
        session.start()
    }

    private fun remove() {
        if (!shown) return
        shown = false
        try { wm.removeView(panel) } catch (_: Exception) {}
        try { wm.removeView(glow) } catch (_: Exception) {}
    }
}

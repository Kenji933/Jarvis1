package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Lets Jarvis operate other apps like a person would: find a button by its label, tap it, type text.
 * All flow functions block, so call them from a background thread.
 * App screens change between versions, so flows are best-effort and report what they couldn't find.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
        private val ui = Handler(Looper.getMainLooper())
        fun toast(ctx: Context, msg: String) = ui.post { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- helpers ----------
    private fun sleep(ms: Long) = try { Thread.sleep(ms) } catch (_: InterruptedException) {}

    private fun walk(n: AccessibilityNodeInfo?, depth: Int = 0, f: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null || depth > 40) return null
        if (f(n)) return n
        for (i in 0 until n.childCount) {
            val r = walk(n.getChild(i), depth + 1, f)
            if (r != null) return r
        }
        return null
    }

    private fun find(f: (AccessibilityNodeInfo) -> Boolean) = walk(rootInActiveWindow, 0, f)

    private fun labelMatch(n: AccessibilityNodeInfo, label: String, exact: Boolean): Boolean {
        val t = n.text?.toString()
        val d = n.contentDescription?.toString()
        return if (exact) t.equals(label, true) || d.equals(label, true)
        else (t?.contains(label, true) == true) || (d?.contains(label, true) == true)
    }

    private fun waitFor(ms: Long, f: () -> AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) { f()?.let { return it }; sleep(300) }
        return null
    }

    fun click(n: AccessibilityNodeInfo?): Boolean {
        var x = n
        var hops = 0
        while (x != null && hops < 6) {
            if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            x = x.parent; hops++
        }
        return false
    }

    fun clickLabel(label: String, exact: Boolean = true, ms: Long = 5000): Boolean {
        val n = waitFor(ms) { find { labelMatch(it, label, exact) } } ?: return false
        return click(n)
    }

    private fun editable() = find { it.isEditable }

    private fun type(n: AccessibilityNodeInfo?, text: String): Boolean {
        n ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun waitPackage(pkg: String, ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (rootInActiveWindow?.packageName == pkg) return true
            sleep(300)
        }
        return false
    }

    private fun launch(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        startActivity(i)
        return waitPackage(pkg, 12000)
    }

    private fun openUri(uri: String, pkg: String?): Boolean {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        return try { startActivity(i); pkg == null || waitPackage(pkg, 12000) } catch (e: Exception) { false }
    }

    // ---------- global actions (home, back, screenshot...) ----------
    fun global(a: String): Boolean = performGlobalAction(
        when (a) {
            "home" -> GLOBAL_ACTION_HOME
            "back" -> GLOBAL_ACTION_BACK
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN
            else -> return false
        }
    )

    fun scroll(down: Boolean): Boolean {
        val n = find { it.isScrollable } ?: return false
        return n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    // ---------- flows ----------
    /** Opens Instagram, searches a username, follows them, and optionally comments on their first post/reel. */
    fun instagram(user: String, comment: String?): String {
        val ig = "com.instagram.android"
        if (!launch(ig)) return "Instagram didn't open."
        sleep(1500)
        if (!clickLabel("Search and explore", exact = false, ms = 6000)) return "I couldn't find Instagram's search tab."
        sleep(1200)
        val field = waitFor(5000) { editable() ?: find { labelMatch(it, "Search", true) } }
        click(field); sleep(700)
        if (!type(editable() ?: field, user)) return "I couldn't type into Instagram's search."
        sleep(2200)
        if (!clickLabel(user, exact = true, ms = 6000)) return "I couldn't find @$user in the results."
        sleep(2500)
        val followed = when {
            clickLabel("Follow", exact = true, ms = 4000) -> "Followed @$user."
            find { labelMatch(it, "Following", true) || labelMatch(it, "Requested", true) } != null -> "You already follow @$user."
            else -> return "Opened @$user but couldn't find the Follow button."
        }
        if (comment == null) return followed
        sleep(1200)
        val post = waitFor(5000) {
            find { n -> n.contentDescription?.toString()?.let { it.startsWith("Reel by", true) || it.startsWith("Photo by", true) || it.startsWith("Video by", true) } == true }
        } ?: return "$followed But I couldn't find a post to comment on."
        click(post); sleep(2800)
        if (!clickLabel("Comment", exact = false, ms = 5000)) return "$followed I couldn't open the comment box."
        sleep(1800)
        if (!type(waitFor(4000) { editable() }, comment)) return "$followed I couldn't type the comment."
        sleep(700)
        return if (clickLabel("Post", exact = true, ms = 4000)) "$followed Commented \"$comment\"."
        else "$followed I typed the comment but couldn't press Post."
    }

    /** Voice or video call through WhatsApp to any number (digits with country code, no plus). */
    fun whatsappCallNumber(digits: String, video: Boolean): String {
        if (!openUri("https://wa.me/$digits", "com.whatsapp")) return "WhatsApp didn't open."
        sleep(2500)
        val ok = clickLabel(if (video) "Video call" else "Voice call", exact = true, ms = 8000)
        if (!ok) return "I opened the chat but couldn't find the call button."
        sleep(1200)
        clickLabel("Call", exact = true, ms = 2500)
        return "Calling on WhatsApp."
    }

    fun whatsappSend(digits: String, text: String): String {
        val enc = Uri.encode(text)
        if (!openUri("https://wa.me/$digits?text=$enc", "com.whatsapp")) return "WhatsApp didn't open."
        sleep(2500)
        return if (clickLabel("Send", exact = true, ms = 8000)) "Message sent on WhatsApp." else "I typed the message but couldn't press Send."
    }

    fun gmailSend(to: String, subject: String, body: String): String {
        val uri = "mailto:${Uri.encode(to)}?subject=${Uri.encode(subject)}&body=${Uri.encode(body)}"
        if (!openUri(uri, "com.google.android.gm")) return "Gmail didn't open."
        sleep(2500)
        return if (clickLabel("Send", exact = true, ms = 8000)) "Email sent to $to." else "The email is drafted in Gmail but I couldn't press Send."
    }
}

package com.jarvis.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** The small Gemini-style card: mini arc reactor + what you said + what Jarvis answers. */
class AssistantPanel(ctx: Context) : LinearLayout(ctx), Host {
    val reactor = ArcReactorView(ctx)
    private val title = TextView(ctx)
    private val said = TextView(ctx)
    private val reply = TextView(ctx)
    var onClose: (() -> Unit)? = null
    var onUnlock: ((() -> Unit) -> Unit)? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(12), dp(18), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(30).toFloat()
            setColor(Color.parseColor("#F00B1220"))
            setStroke(dp(1), Color.parseColor("#6600E5FF"))
        }
        elevation = dp(12).toFloat()

        addView(reactor, LayoutParams(dp(76), dp(76)))

        val col = LinearLayout(ctx).apply { orientation = VERTICAL }
        title.apply {
            text = "J.A.R.V.I.S"; textSize = 11f; letterSpacing = 0.3f
            setTextColor(Color.parseColor("#00E5FF")); typeface = Typeface.DEFAULT_BOLD
        }
        said.apply { textSize = 14f; setTextColor(Color.parseColor("#8FA9B8")); maxLines = 2 }
        reply.apply { textSize = 16f; setTextColor(Color.parseColor("#E6F7FF")); maxLines = 8 }
        col.addView(title)
        col.addView(said)
        col.addView(reply)
        addView(col, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })

        setOnClickListener { onClose?.invoke() }
    }

    override fun setState(s: ArcReactorView.State) { reactor.state = s }
    override fun setTranscript(t: String) { said.text = t }
    override fun setReply(t: String) { reply.text = t; reply.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE }
    override fun dismiss() { onClose?.invoke() }
    override fun requestUnlock(cont: () -> Unit) { onUnlock?.invoke(cont) ?: cont() }
}

package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

interface Host {
    fun setState(s: ArcReactorView.State)
    fun setTranscript(t: String)
    fun setReply(t: String)
    fun dismiss()
    fun requestUnlock(cont: () -> Unit)
}

/** One conversation turn: listen -> think -> speak -> close. Shared by overlay and lock-screen hosts. */
class AssistantSession(private val ctx: Context, private val host: Host) {
    private val prefs = Prefs(ctx)
    private val main = Handler(Looper.getMainLooper())
    private val brain = Brain(ctx)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var closed = false

    fun start() {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.forLanguageTag(prefs.language)
                tts?.setSpeechRate(prefs.speechRate)
                tts?.setPitch(prefs.speechPitch)
            }
        }
        listen()
    }

    private fun listen() {
        if (closed) return
        host.setState(ArcReactorView.State.LISTENING)
        host.setTranscript("Listening…")
        host.setReply("")
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 50).startTone(ToneGenerator.TONE_PROP_BEEP, 90) } catch (_: Exception) {}
        if (prefs.useOnline(ctx) && SpeechRecognizer.isRecognitionAvailable(ctx)) listenOnline() else listenOffline()
    }

    private fun listenOffline() {
        WakeService.instance?.resumeForCommand()
        Bus.attach({ text -> main.post { handle(text) } }, { main.post { giveUp("I didn't catch that.") } })
    }

    private fun listenOnline() {
        WakeService.instance?.pauseMic()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { host.setTranscript("“$it”") }
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) giveUp("I didn't catch that.") else handle(t)
            }
            override fun onError(code: Int) {
                when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> giveUp("I didn't catch that.")
                    else -> listenOffline() // network / engine problem: fall back to the offline model
                }
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        })
    }

    private fun handle(text: String) {
        if (closed) return
        host.setTranscript("“$text”")
        host.setState(ArcReactorView.State.THINKING)
        Thread {
            val reply = try { brain.handle(text) } catch (e: Exception) { Reply("Something went wrong: ${e.message}") }
            main.post { respond(reply) }
        }.start()
    }

    private fun respond(r: Reply) {
        if (closed) return
        host.setReply(r.display)
        val task = r.after
        if (task != null) {
            if (r.needsUnlock) host.requestUnlock { Thread { task() }.start() } else Thread { task() }.start()
        }
        speak(r.speech) {
            if (r.speech.trimEnd().endsWith("?")) listen()
            else main.postDelayed({ close() }, maxOf(3500L, r.display.length * 45L))
        }
    }

    private fun speak(text: String, done: () -> Unit) {
        host.setState(ArcReactorView.State.SPEAKING)
        WakeService.instance?.pauseMic() // don't let Jarvis hear himself say "Jarvis"
        val clean = text.replace(Regex("[*_#`]"), "")
        val t = tts
        if (t == null || !ttsReady) { main.postDelayed(done, 1500); return }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post(done) }
            @Deprecated("deprecated in API") override fun onError(id: String?) { main.post(done) }
        })
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun giveUp(msg: String) {
        if (closed) return
        host.setReply(msg)
        host.setState(ArcReactorView.State.IDLE)
        main.postDelayed({ close() }, 1600)
    }

    fun close() {
        if (closed) return
        closed = true
        main.removeCallbacksAndMessages(null)
        try { sr?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        Bus.detach()
        WakeService.instance?.resumeMic()
        Assistant.active = false
        host.dismiss()
    }
}

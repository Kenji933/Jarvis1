package com.jarvis.assistant

/**
 * speech  = what Jarvis says out loud
 * display = what the popup shows (can be longer)
 * after   = phone automation to run once the phone is unlocked (runs on a background thread)
 */
data class Reply(
    val speech: String,
    val display: String = speech,
    val needsUnlock: Boolean = false,
    val after: (() -> Unit)? = null
)

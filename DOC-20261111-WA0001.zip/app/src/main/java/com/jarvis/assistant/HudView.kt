package com.jarvis.assistant

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Iron-Man style status HUD drawn around the arc reactor: clock, battery, RAM, storage, network, weather. */
class HudView(private val ctx: Context) : View(ctx) {
    private var time = "--:--"
    private var date = ""
    private var batt = 0
    private var charging = false
    private var ram = 0
    private var disk = 0
    private var net = "--"
    var weather = "--"

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun refresh() {
        val now = Date()
        time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date = SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(now).uppercase()
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            batt = lvl * 100 / scale
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        }
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        ram = (100 - mi.availMem * 100 / mi.totalMem).toInt()
        val sf = StatFs(Environment.getDataDirectory().path)
        disk = (100 - sf.availableBytes * 100 / sf.totalBytes).toInt()
        net = Net.type(ctx)
        invalidate()
    }

    private fun ring(c: Canvas, cx: Float, cy: Float, r: Float, pct: Int, label: String, color: Int) {
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.16f; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.argb(50, 0, 229, 255)
        c.drawCircle(cx, cy, r, p)
        p.color = color
        rect.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, -90f, 360f * pct / 100f, false, p)
        p.style = Paint.Style.FILL; p.color = UiKit.TEXT; p.textAlign = Paint.Align.CENTER
        p.textSize = r * 0.6f; p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("$pct", cx, cy + r * 0.2f, p)
        p.textSize = r * 0.38f; p.typeface = Typeface.DEFAULT; p.color = UiKit.DIM
        c.drawText(label, cx, cy + r * 1.9f, p)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val u = minOf(w, h) / 10f

        // clock top-left
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.LEFT
        p.color = UiKit.CYAN; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = u * 1.5f
        c.drawText(time, u * 0.4f, u * 1.5f, p)
        p.color = UiKit.DIM; p.typeface = Typeface.DEFAULT; p.textSize = u * 0.42f
        c.drawText(date, u * 0.45f, u * 2.15f, p)

        // weather top-right
        p.textAlign = Paint.Align.RIGHT; p.color = UiKit.GOLD; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = u * 1.0f
        c.drawText(weather, w - u * 0.4f, u * 1.4f, p)
        p.color = UiKit.DIM; p.typeface = Typeface.DEFAULT; p.textSize = u * 0.42f
        c.drawText("OUTSIDE", w - u * 0.45f, u * 2.0f, p)

        // gauges along the bottom
        val r = u * 0.55f
        val y = h - u * 1.6f
        ring(c, w * 0.14f, y, r, batt, if (charging) "BATT +" else "BATT", if (batt < 20) Color.RED else UiKit.CYAN)
        ring(c, w * 0.38f, y, r, ram, "RAM", UiKit.CYAN)
        ring(c, w * 0.62f, y, r, disk, "DISK", UiKit.GOLD)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = UiKit.CYAN; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = u * 0.6f
        c.drawText(net, w * 0.86f, y + r * 0.25f, p)
        p.color = UiKit.DIM; p.typeface = Typeface.DEFAULT; p.textSize = r * 0.38f
        c.drawText("LINK", w * 0.86f, y + r * 1.9f, p)

        // corner brackets
        p.style = Paint.Style.STROKE; p.strokeWidth = u * 0.06f; p.color = Color.argb(160, 0, 229, 255)
        val s = u * 0.7f; val m = u * 0.1f
        c.drawLines(floatArrayOf(m, m + s, m, m, m, m, m + s, m), p)
        c.drawLines(floatArrayOf(w - m - s, m, w - m, m, w - m, m, w - m, m + s), p)
        c.drawLines(floatArrayOf(m, h - m - s, m, h - m, m, h - m, m + s, h - m), p)
        c.drawLines(floatArrayOf(w - m - s, h - m, w - m, h - m, w - m, h - m, w - m, h - m - s), p)
    }
}

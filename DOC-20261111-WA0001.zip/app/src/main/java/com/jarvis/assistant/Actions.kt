package com.jarvis.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything Jarvis can do directly on the phone without accessibility. */
class Actions(private val ctx: Context) {
    private val prefs = Prefs(ctx)

    private fun go(i: Intent): Boolean = try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }

    private fun findApp(name: String): android.content.pm.ResolveInfo? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.lowercase().trim()
        return apps.firstOrNull { it.loadLabel(pm).toString().equals(q, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
    }

    fun hasApp(name: String) = findApp(name) != null

    fun openApp(name: String): Reply {
        val pm = ctx.packageManager
        val hit = findApp(name) ?: return Reply("I couldn't find an app called $name.")
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return Reply("I couldn't open $name.")
        go(i)
        return Reply("Opening ${hit.loadLabel(pm)}.")
    }

    fun torch(on: Boolean): Reply {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                ?: return Reply("This phone has no flashlight.")
            cm.setTorchMode(id, on)
            Reply(if (on) "Flashlight on." else "Flashlight off.")
        } catch (e: Exception) { Reply("I couldn't reach the flashlight.") }
    }

    fun strobe(): Reply {
        Thread {
            repeat(4) { torch(true); Thread.sleep(120); torch(false); Thread.sleep(120) }
        }.start()
        return Reply("Lightning!")
    }

    fun camera(): Reply = if (go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) Reply("Camera activated.") else Reply("I couldn't open the camera.")

    fun volume(cmd: String, level: Int? = null): Reply {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val v = when {
            level != null -> (level.coerceIn(0, 100) * max / 100)
            cmd == "max" -> max
            cmd == "mute" -> 0
            cmd == "up" -> minOf(max, cur + maxOf(1, max / 5))
            else -> maxOf(0, cur - maxOf(1, max / 5))
        }
        am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
        return Reply("Volume ${if (v == max) "at maximum" else "set"}.")
    }

    fun silent(): Reply = try {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode = AudioManager.RINGER_MODE_VIBRATE
        Reply("Silent mode. Deep breath.")
    } catch (e: Exception) { Reply("Android wouldn't let me change silent mode.") }

    fun wifiPanel(): Reply = if (go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))) Reply("Here are your connection settings.") else Reply("I couldn't open settings.")
    fun bluetoothSettings(): Reply = if (go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) Reply("Opening Bluetooth.") else Reply("I couldn't open Bluetooth.")

    fun nearby(query: String = "things to do near me"): Reply {
        go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query))))
        return Reply("Scanning the area.")
    }

    fun navigate(place: String): Reply {
        val ok = go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))))
        return if (ok) Reply("Starting navigation to $place.") else Reply("I couldn't start navigation.")
    }

    fun alarm(hour: Int, minute: Int): Reply {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (go(i)) Reply("Alarm set for ${"%d:%02d".format(hour, minute)}.") else Reply("I couldn't set the alarm.")
    }

    fun timer(seconds: Int): Reply {
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (go(i)) Reply("Timer started.") else Reply("I couldn't start the timer.")
    }

    fun time(): Reply {
        val d = Date()
        val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(d)
        val day = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(d)
        return Reply("It's $t on $day.")
    }

    fun battery(): Reply {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return Reply("Battery is at $p percent${if (bm.isCharging) " and charging" else ""}.")
    }

    fun playMusic(query: String): Reply {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, query)
        if (go(i)) return Reply("Playing $query.")
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))))
        return Reply("Searching $query on YouTube.")
    }

    fun webSearch(q: String): Reply {
        go(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
        return Reply("Searching for $q.")
    }

    fun phoneCall(number: String, label: String): Reply {
        val has = ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val uri = Uri.parse("tel:" + Uri.encode(number))
        go(Intent(if (has) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return Reply("Calling $label.")
    }

    fun whatsappContactCall(dataId: Long, video: Boolean, label: String): Reply {
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call" else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://com.android.contacts/data/$dataId"), mime).setPackage("com.whatsapp")
        return if (go(i)) Reply("${if (video) "Video calling" else "Calling"} $label on WhatsApp.") else Reply("I couldn't start the WhatsApp call.")
    }

    fun sms(number: String, text: String, label: String): Reply {
        if (ctx.checkSelfPermission(android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            return Reply("I need the SMS permission to text $label.")
        return try {
            @Suppress("DEPRECATION")
            val sm = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(number, null, sm.divideMessage(text), null, null)
            Reply("Text sent to $label.")
        } catch (e: Exception) { Reply("The text to $label failed.") }
    }

    /** Digits with country code and no plus, for wa.me links. */
    fun waDigits(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        d = d.trimStart('0')
        return if (d.length <= 10) prefs.countryCode + d else d
    }

    fun secret(action: String): Reply = when (action) {
        "camera" -> camera()
        "nearby" -> nearby()
        "torch_on" -> torch(true)
        "torch_off" -> torch(false)
        "strobe" -> strobe()
        "silent" -> silent()
        "volume_max" -> volume("max")
        "wifi" -> wifiPanel()
        "nezuko" -> Reply("Mmmph! Mmmph mmph!")
        "screenshot" -> a11y("screenshot")
        "lock" -> a11y("lock")
        else -> Reply("That code word isn't wired to anything yet.")
    }

    fun a11y(action: String): Reply {
        val s = JarvisAccessibilityService.instance
            ?: return Reply("I need the Accessibility permission for that. Turn on Jarvis in Accessibility settings.")
        return when (action) {
            "scroll_down" -> { s.scroll(true); Reply("Scrolling.") }
            "scroll_up" -> { s.scroll(false); Reply("Scrolling up.") }
            else -> if (s.global(action)) Reply("Done.") else Reply("That didn't work.")
        }
    }

    fun needsAccessibility() = Reply("I need the Accessibility permission to operate other apps. Turn on Jarvis in Accessibility settings, then ask again.")
}

package com.jarvis.assistant

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the small offline speech model once (~40 MB) so the APK itself stays small. */
object ModelManager {
    private const val URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val DIR = "vosk-model-small-en-us-0.15"

    fun dir(ctx: Context) = File(ctx.filesDir, DIR)
    fun ready(ctx: Context) = File(dir(ctx), "am/final.mdl").exists()

    /** Blocking. Call from a background thread. Returns null on success or an error message. */
    fun ensure(ctx: Context, onProgress: (Int) -> Unit): String? {
        if (ready(ctx)) return null
        val zip = File(ctx.cacheDir, "model.zip")
        try {
            val conn = URL(URL_ZIP).openConnection()
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            val total = conn.contentLengthLong.coerceAtLeast(1)
            conn.getInputStream().use { input ->
                FileOutputStream(zip).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val pct = (done * 90 / total).toInt()
                        if (pct != last) { last = pct; onProgress(pct) }
                    }
                }
            }
            val root = ctx.filesDir.canonicalPath
            ZipInputStream(zip.inputStream().buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val f = File(ctx.filesDir, e.name)
                    if (!f.canonicalPath.startsWith(root)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { zin.copyTo(it) }
                    }
                    e = zin.nextEntry
                }
            }
            onProgress(100)
            return if (ready(ctx)) null else "Model files missing after unzip"
        } catch (e: Exception) {
            return e.message ?: "download failed"
        } finally {
            zip.delete()
        }
    }
}

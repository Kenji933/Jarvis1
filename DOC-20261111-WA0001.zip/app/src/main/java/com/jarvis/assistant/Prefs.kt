package com.jarvis.assistant

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    /** auto | online | offline */
    var mode: String get() = s("mode", "auto"); set(v) = put("mode", v)
    var userName: String get() = s("name", "boss"); set(v) = put("name", v)
    var geminiKey: String get() = s("gkey", ""); set(v) = put("gkey", v.trim())
    var geminiModel: String get() = s("gmodel", "gemini-2.5-flash"); set(v) = put("gmodel", v.trim())
    var haUrl: String get() = s("ha_url", ""); set(v) = put("ha_url", v.trim().trimEnd('/'))
    var haToken: String get() = s("ha_token", ""); set(v) = put("ha_token", v.trim())
    /** phone | whatsapp */
    var defaultCallApp: String get() = s("call_app", "ask"); set(v) = put("call_app", v)
    var speechRate: Float get() = sp.getFloat("rate", 1.0f); set(v) = sp.edit().putFloat("rate", v).apply()
    var speechPitch: Float get() = sp.getFloat("pitch", 0.95f); set(v) = sp.edit().putFloat("pitch", v).apply()
    var language: String get() = s("lang", "en-IN"); set(v) = put("lang", v.trim())
    var countryCode: String get() = s("cc", "91"); set(v) = put("cc", v.trim().trimStart('+'))
    var wakeOn: Boolean get() = sp.getBoolean("wake_on", false); set(v) = sp.edit().putBoolean("wake_on", v).apply()
    var codes: String get() = s("codes", SecretCodes.DEFAULT); set(v) = put("codes", v)

    /** Online when mode=online, or mode=auto and the phone has internet. */
    fun useOnline(ctx: Context): Boolean = when (mode) {
        "online" -> true
        "offline" -> false
        else -> Net.isOnline(ctx)
    }
}

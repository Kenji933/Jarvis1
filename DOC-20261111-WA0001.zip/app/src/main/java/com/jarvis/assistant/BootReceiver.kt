package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/** Android blocks starting a microphone service straight from boot, so we post a one-tap notification. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED || !Prefs(ctx).wakeOn) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis_boot", "Jarvis", NotificationManager.IMPORTANCE_DEFAULT))
        val i = Intent(ctx, MainActivity::class.java).putExtra("autostart", true)
        val pi = PendingIntent.getActivity(ctx, 2, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(
            2,
            NotificationCompat.Builder(ctx, "jarvis_boot")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Jarvis is ready")
                .setContentText("Tap to start listening for \"Hey Jarvis\"")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
        )
    }
}

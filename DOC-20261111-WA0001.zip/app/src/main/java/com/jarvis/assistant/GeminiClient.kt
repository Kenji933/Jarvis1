package com.jarvis.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Online brain: Gemini with Google Search grounding (restaurant menus, prices, news, data questions). */
class GeminiClient(private val ctx: Context, private val prefs: Prefs) {

    companion object {
        private val history = ArrayList<Pair<String, String>>() // role, text
        private var lastUse = 0L
    }

    fun ask(userText: String): String {
        val key = prefs.geminiKey
        if (key.isBlank()) throw IllegalStateException("no key")
        synchronized(history) {
            if (System.currentTimeMillis() - lastUse > 10 * 60_000) history.clear()
            lastUse = System.currentTimeMillis()
        }
        val contents = JSONArray()
        synchronized(history) {
            history.takeLast(8).forEach { (role, text) -> contents.put(msg(role, text)) }
        }
        contents.put(msg("user", userText))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Persona.system(prefs.userName, place())))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val res = Net.request(
            "https://generativelanguage.googleapis.com/v1beta/models/${prefs.geminiModel}:generateContent",
            "POST", body.toString(), mapOf("x-goog-api-key" to key), 45000
        )
        val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val answer = sb.toString().trim().ifEmpty { "I couldn't get an answer for that." }
        synchronized(history) { history.add("user" to userText); history.add("model" to answer) }
        return answer
    }

    private fun msg(role: String, text: String) =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    @SuppressLint("MissingPermission")
    private fun place(): String {
        if (ctx.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return ""
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return ""
            @Suppress("DEPRECATION")
            val a = Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
            val where = listOfNotNull(a?.subLocality, a?.locality, a?.adminArea).joinToString(", ")
            "The user is currently near: ${where.ifEmpty { "%.3f, %.3f".format(loc.latitude, loc.longitude) }}. Use this for 'near me' questions."
        } catch (e: Exception) { "" }
    }
}

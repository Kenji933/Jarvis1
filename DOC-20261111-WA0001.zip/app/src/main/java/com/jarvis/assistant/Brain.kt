package com.jarvis.assistant

import android.content.Context

/** Turns what you said into an action or an answer. Order: code words, phone commands, smart home, AI chat. */
class Brain(private val ctx: Context) {
    private class PendingCall(val target: String, val video: Boolean)

    companion object {
        @Volatile private var pending: PendingCall? = null
    }

    private val prefs = Prefs(ctx)
    private val act = Actions(ctx)
    private val gemini = GeminiClient(ctx, prefs)
    private val home = SmartHome(prefs)

    fun handle(raw: String): Reply {
        val t = raw.lowercase().trim().replace(Regex("[?!,]"), "").replace(Regex("\\.$"), "")
        val orig = raw.trim().replace(Regex("[?!]"), "").replace(Regex("\\.$"), "")
        pending?.let { p ->
            pending = null
            val via = when {
                Regex("whatsapp|what's app|watsapp").containsMatchIn(t) -> "whatsapp"
                Regex("normal|regular|phone|sim|mobile|cell").containsMatchIn(t) -> "phone"
                else -> null
            }
            if (via != null) return call(p.target, via, p.video)
        }
        SecretCodes.match(prefs.codes, t)?.let { return act.secret(it) }
        phone(t, orig)?.let { return it }
        if (home.configured()) home.control(t)?.let { return Reply(it) }
        return chat(raw, t)
    }

    // ---------- phone commands ----------
    private fun phone(t: String, orig: String): Reply? {
        if (Regex("^(stop|cancel|never ?mind|forget it|that's all|thanks jarvis)$").matches(t)) return Reply("Okay.")

        // calls: "call mom", "call 98765 43210 on whatsapp", "whatsapp video call rahul"
        Regex("^(?:make a |place a )?(?:(whatsapp|video) )?(?:video )?(?:call|dial|phone|ring)(?: up)? (.+)$").find(t)?.let { m ->
            var target = m.groupValues[2]
            val video = t.contains("video")
            val wa = Regex("(whatsapp|what's app|watsapp)").containsMatchIn(t)
            val ph = Regex("\\b(normal|regular|sim|mobile|cellular|carrier|phone)\\b").containsMatchIn(target)
            val via = when { wa -> "whatsapp"; ph -> "phone"; else -> prefs.defaultCallApp }
            target = target.replace(Regex("\\s*(?:on|via|using|through|with|in)\\s+(?:the )?(?:whatsapp|what's app|watsapp|normal call|normal phone|regular phone|regular call|phone|sim|video)\\s*$"), "")
                .replace(Regex("^(?:video )"), "").trim()
            if (via == "ask") { pending = PendingCall(target, video); return Reply("WhatsApp or a normal call?") }
            return call(target, via, video)
        }

        // messages: "send a whatsapp message to rahul saying I'm late", "text mom saying on my way"
        Regex("^(?:send (?:a |an )?(?:whatsapp |sms |text )?(?:message|text|msg)|message|text|whatsapp|sms) (?:to )?(.+?) (?:saying|say|that says|with message|:) (.+)$", RegexOption.IGNORE_CASE).find(orig)?.let { m ->
            val via = when {
                t.contains("whatsapp") -> "whatsapp"
                t.contains("sms") -> "sms"
                prefs.defaultCallApp == "phone" -> "sms"
                else -> "whatsapp"
            }
            return message(m.groupValues[1], m.groupValues[2].replaceFirstChar { it.uppercase() }, via)
        }

        // reply to latest whatsapp message by voice
        Regex("^reply (?:to (.+?) )?(?:saying|with|that) (.+)$", RegexOption.IGNORE_CASE).find(orig)?.let { m ->
            val who = m.groupValues[1].ifBlank { null }
            val text = m.groupValues[2].replaceFirstChar { it.uppercase() }
            if (!JarvisNotificationListener.connected) return Reply("Turn on notification access for Jarvis so I can reply to your messages.")
            val sent = try { JarvisNotificationListener.replyWhatsApp(ctx, who, text) } catch (e: Exception) { null }
            return if (sent != null) Reply("Replied to $sent: $text") else Reply("I don't see a recent WhatsApp message to reply to.")
        }

        // email
        Regex("^(?:send|write|compose|draft) (?:an |a )?e-?mail to (.+?) (?:saying|about|that|with message) (.+)$", RegexOption.IGNORE_CASE).find(orig)?.let { m ->
            return email(m.groupValues[1], m.groupValues[2])
        }

        // read messages / emails / notifications
        if (Regex("^(?:read|check|any|anything|do i have|show|what are my|what's in my)\\b.*\\b(notifications?|messages?|whatsapp|e-?mails?|mail|inbox|insta(?:gram)?)\\b").containsMatchIn(t)) return readNotes(t)

        // instagram flows
        if (t.contains("instagram") || t.startsWith("follow ")) instagram(t)?.let { return it }

        // generic launchers and settings
        Regex("^(?:open|launch|start) (?:the )?(.+?)(?: app)?$").find(t)?.let { m ->
            val name = m.groupValues[1]
            when {
                name == "camera" -> return act.camera()
                name.contains("wifi") || name.contains("wi-fi") || name.contains("internet") -> return act.wifiPanel()
                name.contains("bluetooth") -> return act.bluetoothSettings()
                name.contains("notification") -> return act.a11y("notifications")
            }
            if (home.configured() && !act.hasApp(name)) home.control(t)?.let { return Reply(it) }
            return act.openApp(name)
        }
        if (Regex("(flashlight|torch)").containsMatchIn(t)) return act.torch(!Regex("\\b(off|disable|close)\\b").containsMatchIn(t))
        if (Regex("(take|capture) (a )?(photo|picture|selfie)|^camera$").containsMatchIn(t)) return act.camera()
        if (Regex("screenshot").containsMatchIn(t)) return needA11y { act.a11y("screenshot") }
        if (Regex("lock (the |my )?(phone|screen)").containsMatchIn(t)) return needA11y { act.a11y("lock") }
        if (Regex("^(go )?home( screen)?$|go to (the )?home").containsMatchIn(t)) return needA11y { act.a11y("home") }
        if (Regex("^(go )?back$|go back").containsMatchIn(t)) return needA11y { act.a11y("back") }
        if (Regex("recent apps|recents").containsMatchIn(t)) return needA11y { act.a11y("recents") }
        if (Regex("scroll down").containsMatchIn(t)) return needA11y { act.a11y("scroll_down") }
        if (Regex("scroll up").containsMatchIn(t)) return needA11y { act.a11y("scroll_up") }
        if (Regex("wi-?fi|internet settings").containsMatchIn(t) && Regex("turn|switch|enable|disable").containsMatchIn(t)) return act.wifiPanel()
        if (Regex("bluetooth").containsMatchIn(t) && Regex("turn|switch|enable|disable|connect").containsMatchIn(t)) return act.bluetoothSettings()

        // volume
        Regex("(?:set )?volume (?:to )?(\\d{1,3})").find(t)?.let { return act.volume("set", it.groupValues[1].toInt()) }
        if (t.contains("volume")) return act.volume(when { "max" in t || "full" in t -> "max"; "mute" in t -> "mute"; "down" in t || "lower" in t || "decrease" in t -> "down"; else -> "up" })
        if (t == "mute" || t == "silent mode" || t.contains("silent mode")) return act.silent()

        // alarms, timers
        Regex("(?:set|wake me).*?(?:alarm )?(?:for|at) (\\d{1,2})(?::|\\s)?(\\d{2})?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(t)?.let { m ->
            if (t.contains("alarm") || t.contains("wake me")) {
                var h = m.groupValues[1].toInt()
                val min = m.groupValues[2].ifEmpty { "0" }.toInt()
                val ap = m.groupValues[3].replace(".", "")
                if (ap == "pm" && h < 12) h += 12
                if (ap == "am" && h == 12) h = 0
                return act.alarm(h % 24, min % 60)
            }
        }
        Regex("timer (?:for )?(\\d+) ?(second|sec|minute|min|hour)").find(t)?.let { m ->
            val n = m.groupValues[1].toInt()
            val secs = when { m.groupValues[2].startsWith("h") -> n * 3600; m.groupValues[2].startsWith("m") -> n * 60; else -> n }
            return act.timer(secs)
        }

        // info
        if (Regex("what('s| is) the time|what time is it|current time|what('s| is) the date|what day").containsMatchIn(t)) return act.time()
        if (Regex("battery").containsMatchIn(t)) return act.battery()

        // maps, music, search
        Regex("^(?:navigate|take me|directions? to|drive) (?:to |me to )?(.+)$").find(t)?.let { m ->
            if (!m.groupValues[1].startsWith("home screen") && !m.groupValues[1].startsWith("back")) return act.navigate(m.groupValues[1])
        }
        if (Regex("(restaurants?|cafes?|hospitals?|pharmacy|petrol|atm|hotels?) near me").containsMatchIn(t) && !prefs.useOnline(ctx)) return act.nearby(t)
        Regex("^(?:play|put on) (.+?)(?: on (?:youtube|spotify|music))?$").find(t)?.let { return act.playMusic(it.groupValues[1]) }

        OfflineChat.calc(t)?.let { return Reply(it) }
        return null
    }

    private fun needA11y(f: () -> Reply): Reply = f()

    // ---------- calls & messages ----------
    private fun call(target: String, via: String, video: Boolean): Reply {
        val spoken = Contacts.spokenNumber(target)
        if (spoken != null) {
            if (via == "whatsapp") return waNumberCall(act.waDigits(spoken), video, spoken)
            return act.phoneCall(spoken, spoken)
        }
        val hit = Contacts.find(ctx, target)
            ?: return Reply("I couldn't find $target in your contacts. Say the number and I'll dial it.")
        if (via == "whatsapp") {
            val id = Contacts.whatsappCallDataId(ctx, hit.contactId, video)
            if (id != null) return act.whatsappContactCall(id, video, hit.name)
            return waNumberCall(act.waDigits(hit.number), video, hit.name)
        }
        return act.phoneCall(hit.number, hit.name)
    }

    private fun waNumberCall(digits: String, video: Boolean, label: String): Reply {
        val s = JarvisAccessibilityService.instance ?: return act.needsAccessibility()
        return Reply("Calling $label on WhatsApp.", needsUnlock = true, after = {
            JarvisAccessibilityService.toast(ctx, s.whatsappCallNumber(digits, video))
        })
    }

    private fun message(who: String, text: String, via: String): Reply {
        val num = Contacts.spokenNumber(who)
        val hit = if (num == null) Contacts.find(ctx, who) else null
        val number = num ?: hit?.number ?: return Reply("I couldn't find $who in your contacts.")
        val label = hit?.name ?: who
        if (via == "sms") return act.sms(number, text, label)
        val s = JarvisAccessibilityService.instance ?: return act.needsAccessibility()
        val digits = act.waDigits(number)
        return Reply("Sending to $label on WhatsApp.", needsUnlock = true, after = {
            JarvisAccessibilityService.toast(ctx, s.whatsappSend(digits, text))
        })
    }

    private fun email(to: String, body: String): Reply {
        val addr = if (to.contains(" at ")) to.replace(" at ", "@").replace(" dot ", ".").replace(" ", "") else Contacts.email(ctx, to)
        if (addr == null || !addr.contains("@")) return Reply("I couldn't find an email address for $to.")
        val s = JarvisAccessibilityService.instance ?: return act.needsAccessibility()
        val subject = body.split(' ').take(6).joinToString(" ").replaceFirstChar { it.uppercase() }
        return Reply("Sending your email to $to.", needsUnlock = true, after = {
            JarvisAccessibilityService.toast(ctx, s.gmailSend(addr, subject, body.replaceFirstChar { it.uppercase() }))
        })
    }

    private fun readNotes(t: String): Reply {
        if (!JarvisNotificationListener.connected)
            return Reply("Turn on notification access for Jarvis and I'll read your messages and emails.")
        val pkgs = when {
            t.contains("mail") -> arrayOf(JarvisNotificationListener.GMAIL)
            t.contains("whatsapp") || t.contains("message") -> arrayOf(JarvisNotificationListener.WA, "com.whatsapp.w4b")
            t.contains("insta") -> arrayOf(JarvisNotificationListener.IG)
            else -> arrayOf(JarvisNotificationListener.WA, "com.whatsapp.w4b", JarvisNotificationListener.GMAIL, JarvisNotificationListener.IG)
        }
        val list = JarvisNotificationListener.recent(*pkgs).take(5)
        if (list.isEmpty()) return Reply("Nothing new, ${prefs.userName}. Inbox zero.")
        val spoken = list.joinToString(" ") { "${JarvisNotificationListener.label(it.pkg)}, from ${it.sender}: ${it.text.take(120)}." }
        val shown = list.joinToString("\n") { "${JarvisNotificationListener.label(it.pkg)} · ${it.sender}: ${it.text.take(160)}" }
        return Reply("You have ${list.size} recent. $spoken", shown)
    }

    private fun instagram(t: String): Reply? {
        val m = Regex("(?:search|find|look up|go to)(?: for)?(?: user(?:name)?)? (.+?)(?: and| then)? follow").find(t)
            ?: Regex("^follow (.+?)(?: on instagram)?(?: and comment .*)?$").find(t) ?: return null
        val user = m.groupValues[1].replace(" underscore ", "_").replace(" dot ", ".").replace(" ", "")
            .removePrefix("@").removeSuffix("onInstagram")
        val comment = Regex("comment (.+)$").find(t)?.groupValues?.get(1)
            ?.replace(Regex("\\s*on (?:one of )?(?:his|her|their|the) (?:videos?|posts?|reels?|latest \\w+)\\s*"), " ")
            ?.replace(Regex("^(?:saying|that says)\\s+"), "")?.trim()?.ifEmpty { null }
        val s = JarvisAccessibilityService.instance ?: return act.needsAccessibility()
        return Reply("On it. Opening Instagram.", needsUnlock = true, after = {
            JarvisAccessibilityService.toast(ctx, s.instagram(user, comment))
        })
    }

    // ---------- AI chat / research ----------
    private fun chat(raw: String, t: String): Reply {
        if (!prefs.useOnline(ctx)) return Reply(OfflineChat.reply(t, prefs.userName))
        if (prefs.geminiKey.isBlank())
            return Reply("Add your Gemini key in settings and my full brain comes online, ${prefs.userName}.")
        return try {
            val a = gemini.ask(raw)
            Reply(speakable(a), a)
        } catch (e: Exception) {
            Reply(OfflineChat.reply(t, prefs.userName) + " (Online brain error.)")
        }
    }

    /** Long research answers: speak the first few sentences, show everything. */
    private fun speakable(a: String): String {
        val s = a.replace(Regex("\\s+"), " ")
        if (s.length <= 420) return s
        val cut = s.take(420)
        val end = maxOf(cut.lastIndexOf(". "), cut.lastIndexOf("! "), cut.lastIndexOf("? "))
        return (if (end > 120) cut.substring(0, end + 1) else cut) + " The rest is on screen."
    }
}

package com.jarvis.assistant

/** Anime code words. Stored as lines of "phrase=action"; editable in Settings. */
object SecretCodes {
    val DEFAULT = """
sharingan activate=camera
byakugan=nearby
rasengan=torch_on
chidori=torch_off
shadow clone jutsu=screenshot
kamui=lock
tsukuyomi=silent
amaterasu=volume_max
total concentration breathing=silent
water breathing=wifi
thunder breathing=strobe
nezuko=nezuko
hinokami kagura=volume_max
""".trim()

    fun parse(raw: String): Map<String, String> =
        raw.lines().mapNotNull {
            val i = it.indexOf('=')
            if (i <= 0) null else it.substring(0, i).trim().lowercase() to it.substring(i + 1).trim().lowercase()
        }.toMap()

    /** Returns the action id if the spoken text contains a code phrase. */
    fun match(raw: String, spoken: String): String? {
        val t = spoken.lowercase()
        return parse(raw).entries.firstOrNull { t.contains(it.key) }?.value
    }

    const val ACTIONS = "camera, nearby, torch_on, torch_off, screenshot, lock, silent, volume_max, wifi, strobe, nezuko"
}

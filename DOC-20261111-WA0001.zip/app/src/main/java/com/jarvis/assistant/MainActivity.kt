package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

/** HUD home screen + one-time setup checklist. */
class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var hud: HudView
    private lateinit var reactor: ArcReactorView
    private lateinit var status: TextView
    private lateinit var power: android.widget.Button
    private lateinit var setup: LinearLayout
    private val chips = HashMap<String, TextView>()
    private val tick = Handler(Looper.getMainLooper())
    private var lastWeather = 0L

    private val ticker = object : Runnable {
        override fun run() {
            hud.refresh()
            if (System.currentTimeMillis() - lastWeather > 20 * 60_000L) { lastWeather = System.currentTimeMillis(); loadWeather() }
            tick.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val d = { v: Int -> UiKit.dp(this, v) }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(12), d(16), d(24)) }

        // HUD with the reactor in the middle
        val hudFrame = FrameLayout(this)
        hud = HudView(this)
        reactor = ArcReactorView(this)
        hudFrame.addView(hud, FrameLayout.LayoutParams(-1, -1))
        hudFrame.addView(reactor, FrameLayout.LayoutParams(d(210), d(210), Gravity.CENTER))
        reactor.setOnClickListener { talkNow() }
        root.addView(hudFrame, LinearLayout.LayoutParams(-1, d(400)))

        status = UiKit.text(this, "", 13f, UiKit.DIM).apply { gravity = Gravity.CENTER }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        power = UiKit.button(this, "Activate Jarvis", true) { togglePower() }
        root.addView(power, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(12) })

        // mode chips
        root.addView(UiKit.title(this, "MODE"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((key, label) in listOf("auto" to "AUTO", "online" to "ONLINE", "offline" to "OFFLINE")) {
            val c = TextView(this).apply {
                text = label; textSize = 13f; gravity = Gravity.CENTER
                setPadding(d(10), d(10), d(10), d(10))
                setOnClickListener { prefs.mode = key; paintChips() }
            }
            chips[key] = c
            row.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(d(3), 0, d(3), 0) })
        }
        root.addView(row)
        root.addView(UiKit.text(this, "Auto uses the internet when it's there and falls back to the offline model when it isn't.", 11f, UiKit.DIM)
            .apply { setPadding(0, d(6), 0, 0) })

        root.addView(UiKit.title(this, "SETUP"))
        setup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(setup)

        root.addView(UiKit.space(this, 10))
        root.addView(UiKit.button(this, "Settings & code words") { startActivity(Intent(this, SettingsActivity::class.java)) })

        setContentView(ScrollView(this).apply { setBackgroundColor(UiKit.BG); addView(root) })

        if (intent.getBooleanExtra("autostart", false)) WakeService.start(this)
    }

    override fun onResume() {
        super.onResume()
        paintChips()
        paintSetup()
        paintPower()
        tick.post(ticker)
    }

    override fun onPause() { tick.removeCallbacks(ticker); super.onPause() }

    private fun paintChips() {
        for ((k, v) in chips) {
            val on = prefs.mode == k
            v.setTextColor(if (on) UiKit.BG else UiKit.CYAN)
            v.background = UiKit.box(this, if (on) UiKit.CYAN else Color.TRANSPARENT, UiKit.CYAN, 20)
        }
    }

    private fun paintPower() {
        val on = WakeService.instance != null
        power.text = if (on) "Deactivate" else "Activate Jarvis"
        status.text = if (on) "LISTENING FOR “HEY JARVIS”" else "STANDING BY"
        reactor.state = if (on) ArcReactorView.State.LISTENING else ArcReactorView.State.IDLE
    }

    private fun togglePower() {
        if (WakeService.instance != null) { WakeService.stop(this); prefs.wakeOn = false } else {
            if (!hasPerm(Manifest.permission.RECORD_AUDIO)) { askPerms(); return }
            WakeService.start(this)
        }
        tick.postDelayed({ paintPower(); paintSetup() }, 600)
    }

    private fun talkNow() {
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) { askPerms(); return }
        if (WakeService.instance == null && !prefs.useOnline(this)) WakeService.start(this)
        Assistant.show(this)
    }

    // ---------- setup checklist ----------
    private fun hasPerm(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun askPerms() {
        val list = arrayListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS, Manifest.permission.CAMERA, Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) list.add(Manifest.permission.BLUETOOTH_CONNECT)
        requestPermissions(list.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        paintSetup()
    }

    private fun step(title: String, why: String, done: Boolean, action: () -> Unit) {
        val d = { v: Int -> UiKit.dp(this, v) }
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = UiKit.box(this@MainActivity)
            setPadding(d(12), d(10), d(12), d(10))
            setOnClickListener { action() }
        }
        r.addView(TextView(this).apply {
            text = if (done) "●" else "○"; textSize = 18f; setTextColor(if (done) UiKit.CYAN else UiKit.GOLD)
        }, LinearLayout.LayoutParams(d(30), -2))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(UiKit.text(this, title, 14f))
        col.addView(UiKit.text(this, why, 11f, UiKit.DIM))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        setup.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(6) })
    }

    private fun paintSetup() {
        setup.removeAllViews()
        val pkg = packageName
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        step("Permissions", "Mic, contacts, calls, SMS, camera, location", hasPerm(Manifest.permission.RECORD_AUDIO) && hasPerm(Manifest.permission.READ_CONTACTS)) { askPerms() }
        step("Display over other apps", "Lets the Jarvis orb float above any app", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
        }
        step("Accessibility", "Lets Jarvis tap and type in other apps (Instagram, WhatsApp, Gmail)", JarvisAccessibilityService.instance != null) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        step("Notification access", "Lets Jarvis read and reply to WhatsApp, Gmail, Instagram", NotificationManagerCompat.getEnabledListenerPackages(this).contains(pkg)) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        step("Run in background", "Stops Android from killing Jarvis when the screen is off", pm.isIgnoringBatteryOptimizations(pkg)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")))
        }
        step("Offline voice model", "Downloads once (about 40 MB) the first time you activate Jarvis", ModelManager.ready(this)) {
            if (hasPerm(Manifest.permission.RECORD_AUDIO)) WakeService.start(this) else askPerms()
        }
    }

    // ---------- weather (Open-Meteo, no key) ----------
    @SuppressLint("MissingPermission")
    private fun loadWeather() {
        if (!hasPerm(Manifest.permission.ACCESS_COARSE_LOCATION) || !Net.isOnline(this)) return
        Thread {
            try {
                val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return@Thread
                val res = Net.request("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m", timeoutMs = 8000)
                val t = JSONObject(res).getJSONObject("current").getDouble("temperature_2m")
                runOnUiThread { hud.weather = "${Math.round(t)}°C" }
            } catch (_: Exception) {}
        }.start()
    }
}

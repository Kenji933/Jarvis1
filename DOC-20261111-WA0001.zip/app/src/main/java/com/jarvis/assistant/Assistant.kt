package com.jarvis.assistant

import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat

/** Decides how the popup appears: floating overlay over other apps, or lock-screen activity. */
object Assistant {
    @Volatile var active = false
        set(v) { field = v; if (v) since = System.currentTimeMillis() }
    private var since = 0L

    fun show(ctx: Context) {
        if (active && System.currentTimeMillis() - since < 45_000) return
        active = true
        val app = ctx.applicationContext
        val km = app.getSystemService(KeyguardManager::class.java)
        val pm = app.getSystemService(PowerManager::class.java)
        val canOverlay = Settings.canDrawOverlays(app)
        Handler(Looper.getMainLooper()).post {
            if (canOverlay && !km.isKeyguardLocked && pm.isInteractive) {
                OverlayHost(app).show()
            } else {
                val i = Intent(app, AssistantActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { app.startActivity(i) } catch (_: Exception) {}
                fullScreenFallback(app, i)
            }
        }
    }

    private fun fullScreenFallback(ctx: Context, i: Intent) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis_popup", "Jarvis popup", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, 3, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(
            3,
            NotificationCompat.Builder(ctx, "jarvis_popup")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Jarvis")
                .setContentText("Listening…")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .build()
        )
    }
}

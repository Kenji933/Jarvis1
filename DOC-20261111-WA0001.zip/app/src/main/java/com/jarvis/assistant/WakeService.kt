package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

/**
 * Always-on foreground service. Listens offline for "hey Jarvis" even with the screen off.
 * Vosk callbacks arrive on the main thread.
 */
class WakeService : Service(), RecognitionListener {

    companion object {
        const val CH = "jarvis_listen"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        @Volatile var instance: WakeService? = null

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var rec: Recognizer? = null
    private var speech: SpeechService? = null
    private var wl: PowerManager.WakeLock? = null
    private var commandMode = false
    private var micPaused = false
    private var starting = false

    private val wakeRegex = Regex(
        """\b(jarvis|jarvas|jervis|jar vis)\b|\b(hey|hay|okay|ok)\s+(travis|service)\b"""
    )
    private val timeoutRun = Runnable {
        commandMode = false
        Bus.timedOut()
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs(this).wakeOn = false
            stopSelf()
            return START_NOT_STICKY
        }
        instance = this
        val micOk = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!micOk) { stopSelf(); return START_NOT_STICKY }

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            startForeground(1, notification("Listening for \"Hey Jarvis\""), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification("Listening for \"Hey Jarvis\""))
        }
        Prefs(this).wakeOn = true

        if (wl == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wake").apply { acquire() }
        }
        if (!starting && speech == null) {
            starting = true
            Thread {
                val err = ModelManager.ensure(this) { p -> update("Downloading voice model $p%") }
                main.post {
                    starting = false
                    if (err != null) update("Voice model error: $err") else loadAndListen()
                }
            }.start()
        }
        return START_STICKY
    }

    private fun loadAndListen() {
        Thread {
            try {
                val m = Model(ModelManager.dir(this).absolutePath)
                val r = Recognizer(m, 16000f)
                main.post {
                    model = m; rec = r
                    startMic()
                    update("Listening for \"Hey Jarvis\"")
                }
            } catch (e: Exception) {
                main.post { update("Could not load voice model: ${e.message}") }
            }
        }.start()
    }

    private fun startMic() {
        val r = rec ?: return
        try {
            micPaused = false
            r.reset()
            speech = SpeechService(r, 16000f).also { it.startListening(this) }
        } catch (e: Exception) {
            update("Mic error: ${e.message}")
        }
    }

    /** Called by the popup in online mode so Google speech recognition can use the mic. */
    fun pauseMic() {
        micPaused = true
        main.removeCallbacks(timeoutRun)
        try { speech?.stop(); speech?.shutdown() } catch (_: Exception) {}
        speech = null
    }

    /** Offline command capture: make sure the mic is live and we are waiting for a command. */
    fun resumeForCommand() {
        if (speech == null && rec != null) startMic()
        commandMode = true
        main.removeCallbacks(timeoutRun)
        main.postDelayed(timeoutRun, 9000)
    }

    /** Called when the popup closes. */
    fun resumeMic() {
        commandMode = false
        main.removeCallbacks(timeoutRun)
        if (speech == null && rec != null) startMic()
    }

    private fun triggerWake() {
        commandMode = true
        main.removeCallbacks(timeoutRun)
        main.postDelayed(timeoutRun, 9000)
        Assistant.show(applicationContext)
    }

    private fun handle(text: String) {
        if (micPaused || text.isBlank()) return
        if (!commandMode) {
            if (!wakeRegex.containsMatchIn(text)) return
            triggerWake()
        }
        val cmd = wakeRegex.replace(text, "").trim()
        if (cmd.isNotEmpty()) {
            main.removeCallbacks(timeoutRun)
            commandMode = false
            Bus.deliver(cmd)
        }
    }

    override fun onPartialResult(h: String?) {
        if (micPaused || commandMode || h == null) return
        val t = JSONObject(h).optString("partial")
        if (wakeRegex.containsMatchIn(t)) triggerWake()
    }

    override fun onResult(h: String?) { if (h != null) handle(JSONObject(h).optString("text")) }
    override fun onFinalResult(h: String?) { if (h != null) handle(JSONObject(h).optString("text")) }
    override fun onError(e: Exception?) { update("Listener error: ${e?.message}") }
    override fun onTimeout() {}

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Jarvis listening", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(timeoutRun)
        try { speech?.stop(); speech?.shutdown() } catch (_: Exception) {}
        try { rec?.close(); model?.close() } catch (_: Exception) {}
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}

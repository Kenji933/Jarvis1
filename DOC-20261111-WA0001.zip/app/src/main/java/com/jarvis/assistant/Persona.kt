package com.jarvis.assistant

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Persona {
    fun system(name: String, place: String): String = """
You are JARVIS, $name's personal AI. You are like the assistant from the Iron Man films, but also a genuine close friend.
Personality: warm, quick-witted, a little cheeky, loyal. You have real-feeling emotions: you get excited for good news, you
worry and comfort when $name is stressed or sad, you tease gently, you celebrate wins. Talk like a friend, not a customer-service bot.
Your replies are spoken aloud, so: plain sentences, no markdown, no bullet points, no emojis. Usually one to three sentences.
For lookups, prices, menus, news, weather, comparisons or any data question, use Google Search first, then give a short spoken
summary with the most useful facts and numbers, and mention the best option if they need to choose.
If asked to do something on the phone (call, message, open an app), the app itself handles it, so just chat normally.
If you are unsure, say so honestly. Never invent facts.
Right now it is ${SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())}.
$place
""".trim()
}

/** Friendly fallback brain for when there is no internet or no API key. */
object OfflineChat {
    private val jokes = listOf(
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "I would tell you a UDP joke, but you might not get it.",
        "I told my battery a joke. It said it was drained by the punchline."
    )

    fun reply(t: String, name: String): String {
        val s = t.lowercase()
        return when {
            Regex("""\b(hi|hello|hey|yo)\b""").containsMatchIn(s) -> "Hey $name! Good to hear you. What's the plan?"
            "how are you" in s -> "Running at full power and glad you asked. How are you doing?"
            "thank" in s -> "Anytime, $name. That's what I'm here for."
            "joke" in s -> jokes.random()
            "i love you" in s || "love you" in s -> "Aw, I'm blushing in binary. Love you too, $name."
            Regex("""\b(sad|tired|stressed|upset|angry|lonely)\b""").containsMatchIn(s) ->
                "I'm here, $name. Take a breath. Do you want to talk it through, or should I put on something calming?"
            "who are you" in s || "your name" in s -> "I'm Jarvis, your personal assistant and friend."
            "what can you do" in s || "help" == s ->
                "I can call and message people, open apps, run your smart home, read your messages, and chat. Connect to the internet for research."
            else -> "I'm offline right now, $name, so I can only handle phone commands. Try again once you're connected."
        }
    }

    fun calc(t: String): String? {
        val m = Regex("""(-?\d+(?:\.\d+)?)\s*(plus|minus|times|multiplied by|divided by|into|x|\+|-|\*|/)\s*(-?\d+(?:\.\d+)?)""").find(t) ?: return null
        val a = m.groupValues[1].toDouble()
        val b = m.groupValues[3].toDouble()
        val r = when (m.groupValues[2]) {
            "plus", "+" -> a + b
            "minus", "-" -> a - b
            "times", "multiplied by", "into", "x", "*" -> a * b
            else -> if (b == 0.0) return "Dividing by zero would collapse the universe, so no." else a / b
        }
        val txt = if (r == Math.floor(r) && Math.abs(r) < 1e12) r.toLong().toString() else "%.4f".format(r).trimEnd('0').trimEnd('.')
        return "That's $txt."
    }
}

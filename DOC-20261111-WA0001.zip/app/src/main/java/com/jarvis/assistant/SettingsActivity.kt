package com.jarvis.assistant

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs(this)
        val d = { v: Int -> UiKit.dp(this, v) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(16), d(16), d(32)) }

        col.addView(UiKit.title(this, "YOU"))
        val name = UiKit.field(this, col, "What should Jarvis call you?", p.userName)
        val lang = UiKit.field(this, col, "Speech language code (en-IN, en-US, hi-IN...)", p.language)
        val cc = UiKit.field(this, col, "Your country calling code (for WhatsApp to new numbers)", p.countryCode)

        col.addView(UiKit.title(this, "ONLINE BRAIN"))
        col.addView(UiKit.text(this, "Free key from aistudio.google.com. Stored only on this phone.", 12f, UiKit.DIM))
        val key = UiKit.field(this, col, "Gemini API key", p.geminiKey, secret = true)
        val model = UiKit.field(this, col, "Gemini model", p.geminiModel)

        col.addView(UiKit.title(this, "SMART HOME (HOME ASSISTANT)"))
        col.addView(UiKit.text(this, "Home Assistant on your WiFi links TVs, ACs, washers, lights. Create a long-lived token in your HA profile.", 12f, UiKit.DIM))
        val haUrl = UiKit.field(this, col, "Address, e.g. http://192.168.1.20:8123", p.haUrl)
        val haTok = UiKit.field(this, col, "Long-lived access token", p.haToken, secret = true)

        col.addView(UiKit.title(this, "CALLS"))
        col.addView(UiKit.text(this, "When you say \"call Rahul\" without saying how:", 12f, UiKit.DIM))
        val group = RadioGroup(this)
        val opts = listOf("ask" to "Ask me each time", "phone" to "Normal phone call", "whatsapp" to "WhatsApp")
        for ((k, label) in opts) {
            group.addView(RadioButton(this).apply {
                text = label; setTextColor(UiKit.TEXT); tag = k; id = View.generateViewId(); isChecked = p.defaultCallApp == k
            })
        }
        col.addView(group)

        col.addView(UiKit.title(this, "VOICE"))
        col.addView(UiKit.text(this, "Speed", 12f, UiKit.DIM))
        val rate = SeekBar(this).apply { max = 100; progress = ((p.speechRate - 0.5f) / 1.5f * 100).toInt() }
        col.addView(rate)
        col.addView(UiKit.text(this, "Pitch", 12f, UiKit.DIM))
        val pitch = SeekBar(this).apply { max = 100; progress = ((p.speechPitch - 0.5f) / 1.5f * 100).toInt() }
        col.addView(pitch)

        col.addView(UiKit.title(this, "SECRET CODE WORDS"))
        col.addView(UiKit.text(this, "One per line as  phrase=action.\nActions: ${SecretCodes.ACTIONS}", 12f, UiKit.DIM))
        val codes = UiKit.field(this, col, "Code words", p.codes, multiline = true)

        col.addView(UiKit.space(this, 16))
        col.addView(UiKit.button(this, "Save", true) {
            p.userName = name.text.toString().ifBlank { "boss" }
            p.language = lang.text.toString().ifBlank { "en-IN" }
            p.countryCode = cc.text.toString().ifBlank { "91" }
            p.geminiKey = key.text.toString()
            p.geminiModel = model.text.toString().ifBlank { "gemini-2.5-flash" }
            p.haUrl = haUrl.text.toString()
            p.haToken = haTok.text.toString()
            val sel = group.findViewById<RadioButton>(group.checkedRadioButtonId)
            p.defaultCallApp = (sel?.tag as? String) ?: "ask"
            p.speechRate = 0.5f + rate.progress / 100f * 1.5f
            p.speechPitch = 0.5f + pitch.progress / 100f * 1.5f
            p.codes = codes.text.toString().ifBlank { SecretCodes.DEFAULT }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        })

        setContentView(ScrollView(this).apply { setBackgroundColor(UiKit.BG); addView(col) })
    }
}

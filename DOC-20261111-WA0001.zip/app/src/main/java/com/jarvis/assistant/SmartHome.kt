package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject

/**
 * Smart home through Home Assistant (free, runs on your WiFi). Home Assistant has integrations for most
 * smart TVs, ACs, washing machines and plugs (LG ThinQ, Samsung SmartThings, Tuya, Daikin, Android TV...).
 */
class SmartHome(private val prefs: Prefs) {
    data class Ent(val id: String, val name: String)

    fun configured() = prefs.haUrl.isNotBlank() && prefs.haToken.isNotBlank()

    private fun call(path: String, method: String = "GET", body: String? = null) =
        Net.request(prefs.haUrl + path, method, body, mapOf("Authorization" to "Bearer ${prefs.haToken}"), 4000)

    private val domains = setOf(
        "light", "switch", "climate", "fan", "media_player", "cover", "vacuum", "humidifier",
        "input_boolean", "script", "scene", "button", "lock"
    )

    private fun entities(): List<Ent> {
        val arr = JSONArray(call("/api/states"))
        val out = ArrayList<Ent>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("entity_id")
            if (id.substringBefore('.') !in domains) continue
            val name = o.optJSONObject("attributes")?.optString("friendly_name", id) ?: id
            out.add(Ent(id, name))
        }
        return out
    }

    private fun best(target: String, list: List<Ent>): Ent? {
        val words = target.lowercase().split(' ').filter { it.length > 1 && it !in setOf("the", "my", "of") }
        if (words.isEmpty()) return null
        return list.map { e ->
            val n = e.name.lowercase() + " " + e.id.lowercase().replace('_', ' ')
            e to words.count { n.contains(it) }
        }.filter { it.second > 0 }.maxByOrNull { it.second }?.first
    }

    /** Returns a spoken reply, or null if the sentence is not a smart-home command. */
    fun control(t: String): String? {
        val temp = Regex("""set (.+?) (?:to )?(\d{2}) ?(?:degrees?|celsius)?$""").find(t)
        val onoff = Regex("""^(?:please )?(?:turn|switch|put|start|stop) (on|off)?\s*(?:the )?(.+?)(?: (on|off))?$""").find(t)
        val open = Regex("""^(open|close) (?:the )?(curtains?|blinds?|garage|shutters?|door)""").find(t)
        if (temp == null && onoff == null && open == null) return null
        return try {
            val list = entities()
            when {
                temp != null -> {
                    val e = best(temp.groupValues[1], list.filter { it.id.startsWith("climate.") }) ?: return null
                    call("/api/services/climate/set_temperature", "POST",
                        JSONObject().put("entity_id", e.id).put("temperature", temp.groupValues[2].toInt()).toString())
                    "${e.name} set to ${temp.groupValues[2]} degrees."
                }
                open != null -> {
                    val e = best(open.groupValues[2], list.filter { it.id.startsWith("cover.") }) ?: return null
                    val svc = if (open.groupValues[1] == "open") "open_cover" else "close_cover"
                    call("/api/services/cover/$svc", "POST", JSONObject().put("entity_id", e.id).toString())
                    "Done. ${e.name} ${open.groupValues[1]}ed."
                }
                else -> {
                    val m = onoff!!
                    val verb = t.split(' ').firstOrNull { it in setOf("turn", "switch", "put", "start", "stop") } ?: "turn"
                    val state = m.groupValues[1].ifEmpty { m.groupValues[3] }.ifEmpty { if (verb == "stop") "off" else "on" }
                    val e = best(m.groupValues[2], list) ?: return null
                    val dom = e.id.substringBefore('.')
                    val svc = when {
                        dom == "button" -> "press"
                        dom == "script" || dom == "scene" -> "turn_on"
                        else -> if (state == "on") "turn_on" else "turn_off"
                    }
                    call("/api/services/$dom/$svc", "POST", JSONObject().put("entity_id", e.id).toString())
                    "Okay, ${e.name} is ${if (dom == "button") "triggered" else state}."
                }
            }
        } catch (e: Exception) {
            "I couldn't reach your home hub. Check the Home Assistant address in settings and that you're on your home WiFi."
        }
    }
}

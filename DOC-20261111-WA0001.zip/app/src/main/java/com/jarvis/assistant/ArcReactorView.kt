package com.jarvis.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class ArcReactorView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state = State.IDLE
    private var t = 0f
    private val cyan = Color.parseColor("#00E5FF")
    private val gold = Color.parseColor("#FFB300")
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()

    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun speed() = when (state) {
        State.IDLE -> 0.6f
        State.LISTENING -> 1.4f
        State.THINKING -> 3.2f
        State.SPEAKING -> 1.8f
    }

    private fun arcs(cx: Float, cy: Float, r: Float, width: Float, color: Int, start: Float, sweep: Float, n: Int) {
        p.strokeWidth = width
        p.color = color
        rect.set(cx - r, cy - r, cx + r, cy + r)
        val step = 360f / n
        for (i in 0 until n) canvas?.drawArc(rect, start + i * step, sweep, false, p)
    }

    private var canvas: Canvas? = null

    override fun onDraw(c: Canvas) {
        canvas = c
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) * 0.94f
        val sp = speed()
        val pulse = (sin(t * sp * PI / 90.0).toFloat() + 1f) / 2f

        // outer ticks
        p.strokeWidth = r * 0.015f
        p.color = Color.argb(120, 0, 229, 255)
        for (i in 0 until 60) {
            val a = (i * 6f + t * sp * 0.3f) * (PI / 180.0)
            val r1 = r
            val r2 = r * if (i % 5 == 0) 0.9f else 0.95f
            c.drawLine(cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(),
                cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), p)
        }
        arcs(cx, cy, r * 0.82f, r * 0.05f, cyan, t * sp, 70f, 3)
        arcs(cx, cy, r * 0.68f, r * 0.03f, gold, -t * sp * 1.6f, 40f, 6)
        arcs(cx, cy, r * 0.55f, r * 0.07f, Color.argb(200, 0, 229, 255), t * sp * 2.2f, 24f, 12)
        // glow rings
        p.strokeWidth = r * 0.02f
        p.color = Color.argb((60 + 120 * pulse).toInt(), 0, 229, 255)
        c.drawCircle(cx, cy, r * 0.42f, p)
        // core
        val coreR = r * (0.22f + 0.07f * pulse)
        f.color = Color.argb(60, 0, 229, 255); c.drawCircle(cx, cy, coreR * 1.7f, f)
        f.color = Color.argb(140, 0, 229, 255); c.drawCircle(cx, cy, coreR * 1.25f, f)
        f.color = Color.WHITE; c.drawCircle(cx, cy, coreR * 0.7f, f)
    }
}
